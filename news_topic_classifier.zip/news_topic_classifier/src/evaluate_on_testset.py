import pandas as pd
import pickle
from sklearn.metrics import accuracy_score, classification_report

# Load test.csv
df = pd.read_csv('data/test.csv', header=None)
df.columns = ['label', 'title', 'description']
df['text'] = df['title'] + " " + df['description']
df['label'] = df['label'] - 1

# Load model and vectorizer
model = pickle.load(open("models/logistic_model.pkl", "rb"))
vectorizer = pickle.load(open("models/vectorizer.pkl", "rb"))

# Vectorize and predict
X_test = vectorizer.transform(df['text'])
y_test = df['label']
y_pred = model.predict(X_test)

# Results
print(" Accuracy on test.csv:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))
