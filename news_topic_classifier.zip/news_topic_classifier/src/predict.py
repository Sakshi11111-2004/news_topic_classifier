import pickle

def predict_news(text):
    # Load saved model and vectorizer
    model = pickle.load(open("models/logistic_model.pkl", "rb"))
    vectorizer = pickle.load(open("models/vectorizer.pkl", "rb"))

    # Convert user input to vector
    text_vec = vectorizer.transform([text])

    # Predict category
    pred = model.predict(text_vec)[0]

    # Map label number to category name
    label_map = {
        0: "World",
        1: "Sports",
        2: "Business",
        3: "Sci/Tech"
    }

    return label_map[pred]
