from src.predict import predict_news

print(" Enter a news headline or snippet:")
news = input(">> ")
category = predict_news(news)
print(f"Predicted Category: {category}")
