#  News Topic Classifier (AG News Dataset)

##  What It Does
Classifies a given news article into one of:
- World
- Sports
- Business
- Sci/Tech

##  Tech Stack
- Scikit-learn
- Logistic Regression
- CountVectorizer
- AG News Dataset

##  How to Run

1. Place `train.csv` in `data/`
2. Run training:  
   `python src/train.py`
3. Predict news:  
   `python main.py`

## Accuracy: ~88% on test data
