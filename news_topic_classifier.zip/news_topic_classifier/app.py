import streamlit as st
import pandas as pd
import pickle
from sklearn.metrics import accuracy_score, classification_report
import matplotlib.pyplot as plt

# ── 1. Load model + vectorizer ────────────────────────────────────
model = pickle.load(open("models/logistic_model.pkl", "rb"))
vectorizer = pickle.load(open("models/vectorizer.pkl", "rb"))

label_map = {0: "World", 1: "Sports", 2: "Business", 3: "Sci/Tech"}

# ── 2. Streamlit UI header ───────────────────────────────────────
st.title("📰 News Topic Classifier")
st.write("Enter a news headline or short description and see what the model predicts.")

user_input = st.text_area("Enter News Text", height=100)

# ── 3. Predict & show results ────────────────────────────────────
if st.button("Classify"):
    if not user_input.strip():
        st.warning("Please enter some text first.")
    else:
        vec = vectorizer.transform([user_input])
        pred = model.predict(vec)[0]
        st.success(f"📚 **Predicted Category: {label_map[pred]}**")

        # 3a. Per‑headline probability bar chart
        if hasattr(model, "predict_proba"):
            probs = model.predict_proba(vec)[0]
            st.subheader("🔍 Model confidence for this headline")
            fig_prob, ax_prob = plt.subplots()
            ax_prob.bar(label_map.values(), probs)
            ax_prob.set_ylim(0, 1.0)
            ax_prob.set_ylabel("Probability")
            st.pyplot(fig_prob)
        else:
            st.info("Model was trained without probability=True, so confidence scores are unavailable.")

# ── 4. Overall test‑set performance (static) ─────────────────────
st.divider()
st.subheader("📊 Overall Performance on AG News Official Test Set")

try:
    test_df = pd.read_csv("data/test.csv", header=None)
    test_df.columns = ['label', 'title', 'description']
    test_df['text'] = test_df['title'] + " " + test_df['description']
    test_df['label'] = test_df['label'] - 1

    X_test = vectorizer.transform(test_df['text'])
    y_test = test_df['label']
    y_pred = model.predict(X_test)

    overall_acc = accuracy_score(y_test, y_pred)
    st.metric("Test‑set accuracy", f"{overall_acc*100:.2f}%")

    report = classification_report(y_test, y_pred, output_dict=True)
    f1_scores = [report[str(i)]['f1-score'] for i in range(4)]

    fig_f1, ax_f1 = plt.subplots()
    ax_f1.bar(label_map.values(), f1_scores, color="skyblue")
    ax_f1.set_title("F1 Score by Category (test.csv)")
    ax_f1.set_ylabel("F1 Score")
    ax_f1.set_ylim(0, 1.0)
    st.pyplot(fig_f1)

except Exception as e:
    st.error(f"Could not load data/test.csv or compute metrics: {e}")
